(function(i) {
    return JSON.stringify({ weekProfile: i });
  })(input)