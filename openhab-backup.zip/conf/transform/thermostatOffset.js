(function(i) {
    return '{ "offsetTemp": ' + i + '}';
  })(input)